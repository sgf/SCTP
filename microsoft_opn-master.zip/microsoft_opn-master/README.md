microsoft_opn
=============

OPN (Open Protocol Notation) files from Microsoft's Message Analyzer.